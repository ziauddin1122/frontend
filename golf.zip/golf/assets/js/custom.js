/*---------------------
 thumbs-carousel
---------------------*/
$(document).ready(function() {
    $('.testimonial-slider').owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        items: 1,
        responsiveClass: true,
        autoplay: false,
        responsive: {
            0: {
                items: 1,
            },
            360: {
                items: 1,
            },
            768: {
                items: 1,
            },
            1000: {
                items: 1,
                nav: false,
                dots: true,
                loop: true
            }
        }
    });
    $('.membership-slider').owlCarousel({
        loop: true,
        thumbs: true,
        nav: true,
        items: 3,
        responsiveClass: true,
        autoplay: true,
        margin:40,
        autoplayHoverPause: true,
        slideSpeed: 4000,
        paginationSpeed: 3000,
        autoplayTimeout: 3000,
        navText: ["<i class='fas fa-long-arrow-alt-left'></i>&nbsp;", "<i class='fas fa-long-arrow-alt-right'></i>"],
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            360: {
                items: 1,
            },
            768: {
                items: 3,
                nav: true,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    });
    $('.workout-slider').owlCarousel({
        loop: true,
        thumbs: true,
        nav: true,
        items: 3,
        responsiveClass: true,
        autoplay: true,
        margin:40,
        autoplayHoverPause: true,
        slideSpeed: 4000,
        paginationSpeed: 3000,
        autoplayTimeout: 3000,
        navText: ["<i class='fas fa-long-arrow-alt-left'></i>&nbsp;", "<i class='fas fa-long-arrow-alt-right'></i>"],
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            360: {
                items: 1,
            },
            768: {
                items: 3,
                nav: true,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    });
    $('.testimonial-slider-2').owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        items: 1,
        responsiveClass: true,
        autoplay: false,
        responsive: {
            0: {
                items: 1,
            },
            360: {
                items: 1,
            },
            768: {
                items: 1,
            },
            1000: {
                items: 1,
                nav: false,
                dots: true,
                loop: true
            }
        }
    });
    

});

/*---------------------
 youtube video popUp
---------------------*/
$(document).ready(function() {

    // Gets the video src from the data-src on each button

    var $videoSrc;
    $('.video-btn').click(function() {
        $videoSrc = $(this).data("src");
    });



    // when the modal is opened autoplay it  
    $('#myModal').on('shown.bs.modal', function(e) {

        // set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
        $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
    })



    // stop playing the youtube video when I close the modal
    $('#myModal').on('hide.bs.modal', function(e) {
            // a poor man's stop video
            $("#video").attr('src', $videoSrc);
        })
        // document ready  
});
jQuery(function() {
    jQuery("a.bla-1").YouTubePopUp();
    jQuery("a.bla-2").YouTubePopUp({
        autoplay: 0
    }); // Disable autoplay
});